// https://leetcode.com/problems/minimum-cost-to-set-cooking-time

class Solution {
public:
    int length(int x)
    {
        int z = x;
        int count = 0;
        while(z!=0)
        {
            count++;
            z/=10;
        }
        return count;
    }
    int solve(int startAt,int moveCost,int pushCost,pair<int,int>p)
    {
        if(p.first!=0)
        {
            string s1= to_string(p.first);
        string s2 = to_string(p.second);
        string s = "0";
        
        if(s2.length()==1)
        {
            s.append(s2);
        }
        else
        {
            s = s2;
        }

        s1.append(s);
        int ans = 0;
        if(s1[0]-'0'!=startAt)
        {
            ans+=moveCost;
            ans+=pushCost;
        }
        else
        {
            ans+=pushCost;
        }
        cout<<s1<<endl;
        for(int i = 1;i<s1.length();i++)
        {
            if(s1[i]!=s1[i-1])
            {
                ans+=moveCost;
                ans+=pushCost;
            }
            else
            {
                ans+=pushCost;
            }
        }
        return ans;
        }
        else
        {
            string s1 = to_string(p.second);
            string s = "0";
            if(s1.length()==1)
            {
                s.append(s1);
            }
            else
            {
                s = s1;
            }
            int ans = 0;
        if(s1[0]-'0'!=startAt)
        {
            ans+=moveCost;
            ans+=pushCost;
        }
        else
        {
            ans+=pushCost;
        }
        cout<<s1<<endl;
        for(int i = 1;i<s1.length();i++)
        {
            if(s1[i]!=s1[i-1])
            {
                ans+=moveCost;
                ans+=pushCost;
            }
            else
            {
                ans+=pushCost;
            }
        }
        return ans;
        }
        
    }
    int minCostSetTime(int startAt, int moveCost, int pushCost, int targetSeconds) {
        int maxMin = targetSeconds/60;
        int minSec = targetSeconds-60*maxMin;
        vector<pair<int,int>>v;
        while(length(minSec)<=2 && length(maxMin)<=2)
        {
            v.push_back({maxMin,minSec});
            maxMin--;
            minSec = targetSeconds-60*maxMin;
        }
        int mini = INT_MAX;
        for(auto it:v)
        {
            int ans = solve(startAt,moveCost,pushCost,it);
            cout<<ans<<endl;
            mini = min(mini,ans);
        }
        return mini;
    }
};