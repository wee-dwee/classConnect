// https://leetcode.com/problems/russian-doll-envelopes

class Solution {
public:
    int solve(int curr,int prev,vector<vector<int>>&arr,vector<vector<int>>&dp)
    {
        if(curr>=arr.size())
        return 0;
        if(dp[prev+1][curr]!=-1)
        return dp[prev+1][curr];
        int include = INT_MIN;
        if(prev==-1||(arr[curr][0]>arr[prev][0] && arr[curr][1]>arr[prev][1]))
        {
            include=  1+solve(curr+1,curr,arr,dp);
        }
        int exclude = solve(curr+1,prev,arr,dp);
        return dp[prev+1][curr] = max(include,exclude);
    }
    int maxEnvelopes(vector<vector<int>>& envelopes) {
        sort(envelopes.begin(),envelopes.end());
        int n = envelopes.size();
        vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
        return solve(0,-1,envelopes,dp);
    }
};