// https://leetcode.com/problems/partition-array-into-two-arrays-to-minimize-sum-difference

class Solution {
public:
    void solve(int i,int _2n,vector<int>&nums,vector<int>&out,vector<vector<int>>&ans)
    {
        if(i>=_2n)
        {
            if(out.size()==(_2n/2))
            {
                ans.push_back(out);
            }
            
        }
        out.push_back(nums[i]);
        solve(i+1,_2n,nums,out,ans);
        out.pop_back();
        solve(i+1,_2n,nums,out,ans);
    }
    int minimumDifference(vector<int>& nums) {
        vector<vector<int>>ans;
        vector<int>out;
        int _2n = nums.size();
        int i =  0;
        solve(i,_2n,nums,out,ans);
        for(auto it:ans)
        {
            for(auto jt:it)
            {
                cout<<jt<<" ";
            }
        }
        return 0;
    }
};