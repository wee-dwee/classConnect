// https://leetcode.com/problems/partition-array-into-two-arrays-to-minimize-sum-difference

class Solution {
public:
    void solve(long long i,long long _2n,vector<int>&nums,vector<long long>&out,vector<vector<long long>>&ans)
    {
        if(i>=_2n)
        {
            if(out.size()==(_2n/2))
            {
                ans.push_back(out);
            }
            return ;
        }
        out.push_back(nums[i]);
        solve(i+1,_2n,nums,out,ans);
        out.pop_back();
        solve(i+1,_2n,nums,out,ans);
    }
    int minimumDifference(vector<int>& nums) {
        vector<vector<long long>>ans;
        vector<long long>out;
        long long _2n = nums.size();
        long long i =  0;
        solve(i,_2n,nums,out,ans);
        long long sum = 0;
        for(long long i = 0;i<nums.size();i++)
        {
            sum+=nums[i];
        }
        long long ans1 = LLONG_MAX;
        for(auto it:ans)
        {
            long long sum2 = 0;
            for(auto jt:it)
            {
                sum2+=jt;
            }
            ans1 = min(ans1,abs(sum-2*sum2));
        }
        return ans1;
    }
};