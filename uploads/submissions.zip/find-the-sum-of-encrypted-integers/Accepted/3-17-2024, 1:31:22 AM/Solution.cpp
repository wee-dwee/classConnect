// https://leetcode.com/problems/find-the-sum-of-encrypted-integers

class Solution {
public:
    int largest(int n)
    {
        int maxi = 0;
        int count = 0;
        while(n!=0)
        {
            int digit = n%10;
            maxi = max(maxi,digit);
            n/=10;
            count++;
        }
        int ans =  0;
        char c = maxi+'0';
        string s = "";
        for(int i = 0;i<count;i++)
        {
            s.push_back(c);
        }
        return stoi(s);
    }
    int sumOfEncryptedInt(vector<int>& nums) {
        int sum = 0;
        for(int i = 0;i<nums.size();i++)
        {
            sum+=largest(nums[i]);
        }
        return sum;
    }
};