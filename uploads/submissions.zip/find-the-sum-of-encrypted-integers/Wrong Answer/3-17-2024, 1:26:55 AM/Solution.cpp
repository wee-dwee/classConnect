// https://leetcode.com/problems/find-the-sum-of-encrypted-integers

class Solution {
public:
    int largest(int n)
    {
        int maxi = 0;
        while(n!=0)
        {
            int digit = n%10;
            maxi = max(maxi,digit);
            n/=10;
        }
        return maxi;
    }
    int sumOfEncryptedInt(vector<int>& nums) {
        int sum = 0;
        for(int i = 0;i<nums.size();i++)
        {
            sum+=largest(nums[i]);
        }
        return sum;
    }
};