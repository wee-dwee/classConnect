// https://leetcode.com/problems/find-the-sum-of-encrypted-integers

class Solution {
public:
    int last(int n)
    {
        return n%10;
    }
    int sumOfEncryptedInt(vector<int>& nums) {
        int sum = 0;
        for(int i = 0;i<nums.size();i++)
        {
            sum+=last(nums[i]);
        }
        return sum;
    }
};