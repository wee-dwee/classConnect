// https://leetcode.com/problems/minimum-deletions-to-make-string-k-special

class Solution {
public:
    static bool cmp(pair<char,int>&a,pair<char,int>&b)
    {
        return a.second<b.second;
    }
    int solve(int i,int j,vector<int>&v,vector<vector<int>>&dp,int k)
    {
        if(i==j)
        return 0;
        if(v[j]-v[i]<=k)
        return 0;
        if(dp[i][j]!=-1)
        return dp[i][j];
        int ans = min(v[i]+solve(i+1,j,v,dp,k),v[j]-k-v[i]+solve(i,j-1,v,dp,k));
        return dp[i][j] = ans;
    }
    int minimumDeletions(string word, int k) {
        vector<int>v(26,0);
        for(auto it:word)
        {
            v[it-'a']++;
        }
        sort(v.begin(),v.end());
        vector<vector<int>>dp(v.size()+1,vector<int>(v.size()+1,-1));
        return solve(0,v.size()-1,v,dp,k);
    }
};