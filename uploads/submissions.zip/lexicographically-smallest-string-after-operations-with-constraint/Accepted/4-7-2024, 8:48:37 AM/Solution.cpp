// https://leetcode.com/problems/lexicographically-smallest-string-after-operations-with-constraint

class Solution {
public:
    int solve(char c)
    {
        return min(c-'a',26-(c-'a'));
    }
    string getSmallestString(string s, int k) {
       for(int i = 0;i<s.length();i++)
       {
           int x = solve(s[i]);
           if(k>=x)
           {
               k-=x;
               s[i]='a';
           }
           else
           {
               if(k>0)
               {
                   if(s[i]>=k+'a')
                   {
                       s[i]=char(s[i]-k);
                   }
                   else
                   {
                       s[i] = char('z'-(k-1));
                   }
                   k=0;
               }
               break;
           }
       }
        return s;
    }
};