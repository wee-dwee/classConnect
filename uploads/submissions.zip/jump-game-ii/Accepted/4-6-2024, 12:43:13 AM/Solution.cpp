// https://leetcode.com/problems/jump-game-ii

class Solution {
public:
    int solve(vector<int>&nums,int i,vector<int>&dp)
    {
        if(i==nums.size()-1)
        return 0;
        
        if(dp[i]!=-1)
        return dp[i];

        int ans = INT_MAX;
        for(int j = i+1;j<=i+nums[i] && j<nums.size();j++)
        {
            int x = solve(nums,j,dp);
            ans = min(ans,(x==INT_MAX)?INT_MAX:(1+x));
        }
        return dp[i] = ans;
    }
    int jump(vector<int>& nums) {
        int n = nums.size();
        vector<int>dp(n+1,-1);
        return solve(nums,0,dp);
    }
};