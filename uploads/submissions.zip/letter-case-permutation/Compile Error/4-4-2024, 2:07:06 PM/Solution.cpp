// https://leetcode.com/problems/letter-case-permutation

class Solution {
public:

    vector<string> letterCasePermutation(string s) {
        vector<vector<string>>ans;
        vector<int>v;
        for(auto it:s)
        {
            if(st.find(s[i])!=st.end())
            {
                v.push_back(i);
            }
        }
        
        
        return {};
    }
};