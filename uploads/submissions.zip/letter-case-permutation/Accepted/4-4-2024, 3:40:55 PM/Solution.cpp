// https://leetcode.com/problems/letter-case-permutation



class Solution {
public:
    bool isLetter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    void change(char &c) {
        if (islower(c))
            c = toupper(c);
        else
            c = tolower(c);
    }

    void backtrack(unordered_set<string>& ans, string& s, int index) {
        ans.insert(s);

        for (int i = index; i < s.size(); ++i) {
            if (isLetter(s[i])) {
                change(s[i]); 
                backtrack(ans, s, i + 1);
                change(s[i]); 
            }
        }
    }

    vector<string> letterCasePermutation(string s) {
        unordered_set<string> ans;
        backtrack(ans, s, 0);
        return vector<string>(ans.begin(), ans.end());
    }
};
