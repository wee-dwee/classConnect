// https://leetcode.com/problems/letter-case-permutation

#include <vector>
#include <string>
#include <set>

class Solution {
public:
    bool isLetter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    void change(char &c) {
        if (islower(c))
            c = toupper(c);
        else
            c = tolower(c);
    }

    void solve(set<string> &ans, vector<int> &v, int index, string &s) {
        if (index == v.size()) {
            ans.insert(s);
            return;
        }

        solve(ans, v, index + 1, s); 

        change(s[v[index]]); 
        solve(ans, v, index + 1, s);
        change(s[v[index]]); 
    }

    vector<string> letterCasePermutation(string s) {
        vector<string> ans;
        vector<int> v;

       
        for (int i = 0; i < s.length(); ++i) {
            if (isLetter(s[i]))
                v.push_back(i);
        }

        set<string> uniquePermutations;
        solve(uniquePermutations, v, 0, s);

        return vector<string>(uniquePermutations.begin(), uniquePermutations.end());
    }
};
