// https://leetcode.com/problems/letter-case-permutation

#include <vector>
#include <string>
#include <set>

class Solution {
public:
    bool isLetter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }

    void solve(set<string> &ans, string &s, int index) {
        if (index == s.size()) {
            ans.insert(s);
            return;
        }
        
        if (isLetter(s[index])) {
            
            s[index] = toupper(s[index]);
            solve(ans, s, index + 1);

           
            s[index] = tolower(s[index]);
            solve(ans, s, index + 1);

            
            s[index] = islower(s[index]) ? toupper(s[index]) : tolower(s[index]);
        } else {
            solve(ans, s, index + 1);
        }
    }

    vector<string> letterCasePermutation(string s) {
        set<string> ans;
        solve(ans, s, 0);
        return vector<string>(ans.begin(), ans.end());
    }
};
