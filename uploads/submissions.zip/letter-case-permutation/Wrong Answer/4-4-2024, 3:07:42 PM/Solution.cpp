// https://leetcode.com/problems/letter-case-permutation

class Solution {
public:
    bool isLetter(char c)
    {
        if(c<='z' && c>='a')
        {
            return true;
        }
        if(c<='Z' && c>='A')
        return true;
        return false;
    }
    void change(int i,string &s)
    {
        if(tolower(s[i])==s[i])
        {
            s[i]=toupper(s[i]);
        }
        else
        {
            s[i]=tolower(s[i]);
        }
    }
    void solve(vector<string>&ans,vector<int>&v,int i,string &s)
    {
        if(i>=v.size())
        {
            return;
        }
        for(int j = i;j<v.size();j++)
        {
            change(v[j],s);
            ans.push_back(s);
            solve(ans,v,i+1,s);
            
            change(v[j],s);
        }
    }
    vector<string> letterCasePermutation(string s) {
        vector<string>ans;
        vector<int>v;
        for(int i = 0;i<s.length();i++)
        {
            if(isLetter(s[i]))
            {
                v.push_back(i);
            }
        }
        solve(ans,v,0,s);
        return ans;
    }
};