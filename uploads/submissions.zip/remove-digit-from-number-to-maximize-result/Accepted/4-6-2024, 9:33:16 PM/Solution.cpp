// https://leetcode.com/problems/remove-digit-from-number-to-maximize-result

class Solution {
public:
    string removeDigit(string number, char digit) {
        vector<int>v;
        for(int i = 0;i<number.length();i++)
        {
            if(number[i]==digit)
            {
                v.push_back(i);
            }
        }
        vector<string>arr;
        for(int i = 0;i<v.size();i++)
        {
            string s1 = number;
            s1.erase(v[i], 1);
            arr.push_back(s1);
        }
        string ans = "";
        for(auto it:arr)
        {
            ans=max(ans,it);
        }
        return ans;
    }
};