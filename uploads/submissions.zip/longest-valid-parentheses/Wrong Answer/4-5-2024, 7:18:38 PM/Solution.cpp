// https://leetcode.com/problems/longest-valid-parentheses

class Solution {
public:
    int longestValidParentheses(string s) {
        int ans = INT_MIN;
        int count = 0;
        for(int i = 0;i<s.length();i++)
        {
            if(s[i]=='(')
            count++;
            else
            {
                count--;
            }
            ans = max(ans,count);
        }
        return ans;
    }
};