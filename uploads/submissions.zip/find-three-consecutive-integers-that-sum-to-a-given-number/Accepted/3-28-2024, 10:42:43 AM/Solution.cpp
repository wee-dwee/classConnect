// https://leetcode.com/problems/find-three-consecutive-integers-that-sum-to-a-given-number

class Solution {
public:
    vector<long long> sumOfThree(long long num) {
        vector<long long>ans;
        if(num%3!=0)
            return {};
        ans.push_back((num-3)/3);
        ans.push_back(num/3);
        ans.push_back((num+3)/3);
        return ans;
    }
};