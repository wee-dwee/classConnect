// https://leetcode.com/problems/longest-happy-prefix

class Solution {
public:
    string longestPrefix(string s) {
        unordered_set<string>suffixes;
        unordered_set<string>prefixes;
        string ans = "";
        for(int i = 0;i<s.length()-1;i++)
        {
            ans+=s[i];
            prefixes.insert(ans);
        }
        ans="";
        for(int i = s.length()-1;i>=1;i--)
        {
            ans.insert(0, 1, s[i]);
            suffixes.insert(ans);
        }
        int ans2 =  INT_MIN;
        string main = "";
        for(auto it:prefixes)
        {
            if(suffixes.find(it)!=suffixes.end())
            {
                if(it.length()>ans2)
                {
                    ans2 = it.length();
                    
                    main = it;
                }
                
            }
        }
        return main;
        
    }
};