// https://leetcode.com/problems/divide-array-into-equal-pairs

class Solution {
public:
    bool divideArray(vector<int>& nums) {
        unordered_map<int,int>m;
        for(auto it:nums)
        {
            m[it]++;
        }
        for(auto it:m)
        {
            if(it.second%2==1)
                return false;
        }
        return true;
    }
};