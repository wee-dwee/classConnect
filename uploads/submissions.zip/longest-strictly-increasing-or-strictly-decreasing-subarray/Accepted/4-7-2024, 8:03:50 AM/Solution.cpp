// https://leetcode.com/problems/longest-strictly-increasing-or-strictly-decreasing-subarray

class Solution {
public:
    int longestMonotonicSubarray(vector<int>& nums) {
        if (nums.empty())
        return 0;

    int n = nums.size();
    vector<int> v1(n, 1);
    vector<int> v2(n, 1);

    for (int i = 1; i < n; ++i) {
        if (nums[i] > nums[i - 1])
            v1[i] = v1[i - 1] + 1;
        if (nums[i] < nums[i - 1])
            v2[i] = v2[i - 1] + 1;
    }
    int maxi1 = INT_MIN;
        int maxi2 = INT_MIN;
    for(auto it:v1)
    {
        maxi1 = max(maxi1,it);
    }
        for(auto it:v2)
        {
            maxi2 = max(maxi2,it);
        }
        return max(maxi1,maxi2);
    }
};