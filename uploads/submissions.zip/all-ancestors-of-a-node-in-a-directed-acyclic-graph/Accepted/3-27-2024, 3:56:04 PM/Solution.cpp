// https://leetcode.com/problems/all-ancestors-of-a-node-in-a-directed-acyclic-graph

class Solution {
public:
    void dfs(int node,vector<vector<int>>&v,unordered_map<int,vector<int>>&adj,vector<bool>&visited)
    {
        visited[node] = true;
        for(auto it:adj[node])
        {
            if(!visited[it])
            dfs(it,v,adj,visited);
        }
    }
    vector<vector<int>> getAncestors(int n, vector<vector<int>>& edges) {
        vector<vector<int>>v(n);
        unordered_map<int,vector<int>>adj;
        for(auto it:edges)
        {
            adj[it[0]].push_back(it[1]);
        }
        vector<bool>visited(n,false);
        for(int i = 0;i<n;i++)
        {
            dfs(i,v,adj,visited);
            for(int j = 0;j<visited.size();j++)
            {
                if(visited[j] && j!=i)
                v[j].push_back(i);
                visited[j] = false;
            }
        }
        return v;
    }
};