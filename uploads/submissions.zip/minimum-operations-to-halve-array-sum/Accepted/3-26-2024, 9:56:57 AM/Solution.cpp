// https://leetcode.com/problems/minimum-operations-to-halve-array-sum

class Solution {
public:
    int halveArray(vector<int>& nums) {
        double sum = 0;
        for(auto it:nums)
            sum+=(double)it;
        priority_queue<double>pq;
        for(auto it:nums)
        {
            pq.push((double)it);
        }
        double sum2 = sum/2.0;
        int i= 0;
        while(sum>sum2 && !pq.empty())
        {
            double x = pq.top();
            pq.pop();
            sum-=x/2.0;
            pq.push(x/2.0);
            i++;
        }
        return i;
    }
};