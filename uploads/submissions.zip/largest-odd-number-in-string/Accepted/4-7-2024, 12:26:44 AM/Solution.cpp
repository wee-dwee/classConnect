// https://leetcode.com/problems/largest-odd-number-in-string

class Solution {
public:
    bool isOdd(char c)
    {
        string s = "";
        s.push_back(c);
        int x = stoi(s);
        return x%2==1;
    }
    string largestOddNumber(string num) {
        int i;
        for( i = num.size()-1;i>=0;i--)
        {
            if(isOdd(num[i]))
            {
                break;
            }
        }
        string ans = "";
        for(int j = 0;j<=i;j++)
        {
            ans.push_back(num[j]);
        }

        return ans;
        
    }
};