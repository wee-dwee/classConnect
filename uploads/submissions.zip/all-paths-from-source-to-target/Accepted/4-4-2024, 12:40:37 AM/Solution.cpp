// https://leetcode.com/problems/all-paths-from-source-to-target

class Solution {
public:
    void dfs(int i, unordered_map<int, vector<int>>& adj, vector<int>& visited, int dest, vector<vector<int>>& ans, vector<int>& out) {
        if (i == dest) {
            out.push_back(i);
            ans.push_back(out);
            out.pop_back();
            return;
        }

        out.push_back(i);
        visited[i] = true;
        for (auto it : adj[i]) {
            if (!visited[it]) {
                dfs(it, adj, visited, dest, ans, out);
            }
        }
        out.pop_back();
        visited[i] = false;
    }
    
    vector<vector<int>> allPathsSourceTarget(vector<vector<int>>& graph) {
        int n = graph.size();
        unordered_map<int, vector<int>> adj;
        
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < graph[i].size(); j++) {
                adj[i].push_back(graph[i][j]);
            }
        }

        vector<int> visited(n, false);
        vector<vector<int>> ans;
        vector<int> out;
        dfs(0, adj, visited, n - 1, ans, out);
        return ans;
    }
};
