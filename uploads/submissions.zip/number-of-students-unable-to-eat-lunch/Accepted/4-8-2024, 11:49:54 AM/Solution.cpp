// https://leetcode.com/problems/number-of-students-unable-to-eat-lunch

class Solution {
public:
    int countStudents(vector<int>& students, vector<int>& sandwiches) {
        stack<int>st;
        queue<int>q;
        int n = students.size();
        for(int i = n-1;i>=0;i--)
        {
            st.push(sandwiches[i]);
        }       
        for(int i = 0;i<n;i++)
        {
            q.push(students[i]);
        }
        int count = 0;
        while(!st.empty())
        {
            if(st.top()==q.front())
            {
                st.pop();
                q.pop();
                count++;
            }
            else
            {
                int x = q.size();
                int i;
                for( i = 0;i<x;i++)
                {
                    if(st.top()==q.front())
                    {
                        st.pop();
                        q.pop();
                        count++;
                        break;
                    }
                    else
                    {
                        int z = q.front();
                        q.pop();
                        q.push(z);
                    }
                }
                if(i==x)
                {
                    break;
                }
            }
        }
        return  st.size();
    }
};