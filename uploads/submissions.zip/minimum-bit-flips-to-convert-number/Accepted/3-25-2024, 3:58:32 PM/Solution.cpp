// https://leetcode.com/problems/minimum-bit-flips-to-convert-number

class Solution {
public:
    int number(int x)
    {
        int count = 0;
        while(x!=0)
        {
            if(x%2==1)
                count++;
            x/=2;
        }
        return count;
    }
    int minBitFlips(int start, int goal) {
        int x = start^goal;
        return number(x);
    }
};