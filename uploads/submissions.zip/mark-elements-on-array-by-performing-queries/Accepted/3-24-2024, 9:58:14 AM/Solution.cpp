// https://leetcode.com/problems/mark-elements-on-array-by-performing-queries

class Solution {
public:
    vector<long long> unmarkedSumArray(vector<int>& nums, vector<vector<int>>& queries) {
        long long n = nums.size();
        long long m = queries.size();
        priority_queue<pair<long long,long long>,vector<pair<long long,long long>>,greater<pair<long long,long long>>>pq;
        vector<bool>visited(n,false);
        long long sum = 0;
        for(long long i = 0;i<n;i++)
        {
            sum+=nums[i];
            pq.push({nums[i],i});
        }
        vector<long long>ans(m);
        for(long long i = 0;i<m;i++)
        {
            if(!visited[queries[i][0]])
            {
                visited[queries[i][0]] = true;
                sum-=nums[queries[i][0]];
            }
            long long k = queries[i][1];
            while(k && pq.size()>0)
            {
                pair<long long,long long>top = pq.top();
                pq.pop();
                if(!visited[top.second])
                {
                    visited[top.second] = true;
                    sum-=nums[top.second];
                    k--;
                }
            }
            ans[i] = sum;
        }
        return ans;
    }
};