// https://leetcode.com/problems/jump-game-iii

class Solution {
public:
    bool solve(vector<int>& v, int i) {
        if (i < 0 || i >= v.size() || v[i] < 0)
            return false;

        if (v[i] == 0)
            return true;

        
        v[i] = -v[i];

        
        return solve(v, i + v[i]) || solve(v, i - v[i]);
    }

    bool canReach(vector<int>& arr, int start) {
        return solve(arr, start);
    }
};
