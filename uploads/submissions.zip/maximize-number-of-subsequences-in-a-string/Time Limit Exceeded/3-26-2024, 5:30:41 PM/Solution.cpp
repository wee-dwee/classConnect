// https://leetcode.com/problems/maximize-number-of-subsequences-in-a-string

class Solution {
public:
    long long maximumSubsequenceCount(string text, string pattern) {
        string first = "";
        first.push_back(pattern[0]);
        first.append(text);
        string second = "";
        second.append(text);
        second.push_back(pattern[1]);
        vector<int>v1;
        vector<int>v2;
        for(int i = 0;i<first.length();i++)
        {
            if(first[i]==pattern[0])
            {
                v1.push_back(i);
            }
        }
        int count1 = 0;
        int count2 = 0;
        for(auto it:v1)
        {
            int j = it+1;
            for(j = it+1;j<first.length();j++)
            {
                if(first[j]==pattern[1])
                {
                    count1++;
                }
            }
        }
        for(int i = 0;i<second.length();i++)
        {
            if(second[i]==pattern[0])
            {
                v2.push_back(i);
            }
        }
        for(auto it:v2)
        {
            int j = it+1;
            for(j = it+1;j<second.length();j++)
            {
                if(second[j]==pattern[1])
                {
                    count2++;
                }
            }
        }
        return max(count1,count2);
    }
};