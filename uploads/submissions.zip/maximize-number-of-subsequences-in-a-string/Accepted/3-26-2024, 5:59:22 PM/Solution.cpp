// https://leetcode.com/problems/maximize-number-of-subsequences-in-a-string

#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Solution {
public:
    long long solve(string s1, string pattern) {
        int n = s1.length();
        vector<int> suff(n, 0);
        if (s1[n - 1] == pattern[1]) {
            suff[n - 1] = 1;
        }
        for (int i = n - 2; i >= 0; i--) {
            if (s1[i] == pattern[1]) {
                suff[i] = suff[i + 1] + 1;
            } else {
                suff[i] = suff[i + 1];
            }
        }
        long long count = 0;
        for (int i = 0; i < s1.length(); i++) {
            if (s1[i] == pattern[0]) {
                count += suff[i];
            }
        }
        return count;
    }

    long long maximumSubsequenceCount(string t, string pat) {
        
         long long cnt0 = 1, cnt1 = 1, res0 = 0, res1 = 0;
        for (int i = 0, j = t.size() - 1; j >= 0; ++i, --j) {
            if (t[i] == pat[1])
                res0 += cnt0;
            if (t[j] == pat[0])
                res1 += cnt1;
            cnt0 += t[i] == pat[0];
            cnt1 += t[j] == pat[1];
        }
        return max(res0, res1);
    }
};
