// https://leetcode.com/problems/maximize-number-of-subsequences-in-a-string

#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Solution {
public:
    long long solve(string s1, string pattern) {
        int n = s1.length();
        vector<int> suff(n, 0);
        if (s1[n - 1] == pattern[1]) {
            suff[n - 1] = 1;
        }
        for (int i = n - 2; i >= 0; i--) {
            if (s1[i] == pattern[1]) {
                suff[i] = suff[i + 1] + 1;
            } else {
                suff[i] = suff[i + 1];
            }
        }
        long long count = 0;
        for (int i = 0; i < s1.length(); i++) {
            if (s1[i] == pattern[0]) {
                count += suff[i];
            }
        }
        return count;
    }

    long long maximumSubsequenceCount(string text, string pattern) {
        string first = pattern.substr(0, 1) + text;
        string second = text + pattern.substr(1, 1);
        long long s1 = solve(first, pattern);
        long long s2 = solve(second, pattern);
        return max(s1, s2);
    }
};

