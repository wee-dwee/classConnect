// https://leetcode.com/problems/minimum-levels-to-gain-more-points

class Solution {
public:
    int minimumLevels(vector<int>& possible) {
        int n = possible.size();
       for(int i = 0;i<n;i++)
       {
        if(possible[i]==0)
        {
            possible[i]=-1;
        }
        else
        {
            possible[i]=1;
        }
       }
       int sum = 0;
       for(int i=0;i<n;i++)
       {
            sum+=possible[i];
       }
       int sum1=0,sum2=0;
       for(int i=0;i<n;i++)
        {
            sum1+=possible[i];
            cout<<sum1<<endl;
            sum2=sum-sum1;
            cout<<sum2<<endl;
            if(sum1>sum2)
            {
                return i+1;
            }
        }
        return -1;
    }
};