// https://leetcode.com/problems/minimum-levels-to-gain-more-points

class Solution {
public:
    int minimumLevels(vector<int>& possible) {
        int BobMax = 0;
        int n = possible.size();
        for(int i=0;i<n;i++){
            if(possible[i]==1) BobMax+=1;
            else BobMax-=1;
        }
        int danScore = 0;
        for(int i=0;i<n-1;i++){
            if(possible[i]==1){
                danScore+=1;
                BobMax-=1;
            }
            else{
                danScore-=1;
                BobMax+=1;
            }
            if(danScore>BobMax) return i+1;
        }
        return -1;
    }
};