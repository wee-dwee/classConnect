// https://leetcode.com/problems/count-subarrays-where-max-element-appears-at-least-k-times

class Solution {
public:
    long long countSubarrays(vector<int>& nums, int k) {
        int maxi = INT_MIN;
        int n = nums.size();
        for(int i = 0; i < n; i++) {
            maxi = max(maxi, nums[i]);
        }
        
        vector<int>pref(n,0);
        if(nums[0]==maxi)
        pref[0] = 1;
        for(int i = 1;i<n;i++)
        {
            if(nums[i]==maxi)
            {
                pref[i] = pref[i-1]+1;
            }
            else
            {
                pref[i] = pref[i-1];
            }
        }
        long long ans= 0;
        for(int i = 0;i<pref.size();i++)
        {
            int l = i;
            int curr = pref[i];
            int required = k+pref[i]-(nums[i]==maxi?1:0);
            auto it = lower_bound(pref.begin(),pref.end(),required);
            if(it==pref.end())
            break;
            int r = it-pref.begin();
            ans+=pref.size()-r;
        }
        
        return ans;
    }
};
