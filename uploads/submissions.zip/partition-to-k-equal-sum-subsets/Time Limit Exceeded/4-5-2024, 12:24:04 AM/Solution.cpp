// https://leetcode.com/problems/partition-to-k-equal-sum-subsets

class Solution {
public:
    bool solve(int sum,int k,int i ,vector<int>&nums,int targetSum,vector<bool>&visited)
    {
        if(k==1)
        return true;
        if(sum==targetSum)
        {
            return solve(0,k-1,0,nums,targetSum,visited);
        }
        for(int j = i;j<nums.size();j++)
        {
            if(visited[j]||sum+nums[j]>targetSum)
            continue;

            visited[j] = true;
            if(solve(sum+nums[j],k,j+1,nums,targetSum,visited))
            return true;
            visited[j] = false;
        }
        return false;
    }
    bool canPartitionKSubsets(vector<int>& nums, int k) {
        int sum = 0;
        for(int i = 0;i<nums.size();i++)
        {
            sum+=nums[i];
        }
        sort(nums.begin(),nums.end());
        if(sum%k!=0 || nums.size()<k)
        return false;
        else
        {
            int targetSum = sum/k;
            vector<bool>visited(nums.size(),false);
            return solve(0,k,0,nums,targetSum,visited);
            
        }
    }

};