// https://leetcode.com/problems/triangle

class Solution {
public:
    int solve(int i,int j,vector<vector<int>>&triangle,vector<vector<int>>&dp)
    {
        if(i>=triangle.size())
        return 0;
        if(dp[i][j]!=-1)
        {
            return dp[i][j];
        }
        int ans1,ans2;
        if(j<triangle.size())
        {
            ans1 = solve(i+1,j,triangle,dp);
            ans2 = solve(i+1,j+1,triangle,dp);
        }
        return dp[i][j] = min(ans1,ans2)+triangle[i][j];
    }
    int minimumTotal(vector<vector<int>>& triangle) {
        int n = triangle.size();
        vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
        return solve(0,0,triangle,dp);
    }
};