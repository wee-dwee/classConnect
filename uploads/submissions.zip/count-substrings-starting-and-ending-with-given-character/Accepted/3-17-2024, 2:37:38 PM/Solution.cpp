// https://leetcode.com/problems/count-substrings-starting-and-ending-with-given-character

class Solution {
public:
    long long countSubstrings(string s, char c) {
        long long ans;
        long long count = 0;
        for(auto it:s)
        {
            if(it==c)
                count++;
        }
        return ((count)*(count+1))/2;
    }
};