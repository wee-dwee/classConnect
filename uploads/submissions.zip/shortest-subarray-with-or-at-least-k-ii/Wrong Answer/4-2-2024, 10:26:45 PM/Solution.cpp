// https://leetcode.com/problems/shortest-subarray-with-or-at-least-k-ii

class Solution {
public:
  bool set(int num, int i) {
    return ((1 << i) & num) != 0;
  }

  int add(int v[], int x, int num) {
    for (int i = 0; i < 32; i++) {
      if (set(num, i) && set(x,i)) {
        v[i]+=2;
      }
      else if(set(num,i) && !set(x,i))
      {
        v[i]++;
      }
      else if(!set(num,i) && set(x,i))
      {
        v[i]++;
      }
    }
    return x|num;
  }

  
  int remove(int v[], int x, int num) {
    long ans = 0;
    for(int i = 0;i<32;i++)
    {
        if(set(x,i))
        {
            v[i]--;
        }
        ans+=v[i]*pow(2,31-i);
    }
    return ans;
  }

  int minimumSubarrayLength(vector<int>& nums, int k) {
    int n = nums.size(), ans = INT_MAX;
    int v[32] = {0}; 
    int x = 0, i = 0;
    for (int j = 0; j < n; j++) {
      x = add(v, x, nums[j]);
      while (x >= k && i <= j) {
        ans = min(ans, j - i + 1);
        x = remove(v, x, nums[i]);
        i++;
      }
      
    }
    return (ans == INT_MAX ? -1 : ans);
  }
};
