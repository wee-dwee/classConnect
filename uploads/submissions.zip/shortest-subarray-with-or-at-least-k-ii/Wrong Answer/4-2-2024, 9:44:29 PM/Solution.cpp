// https://leetcode.com/problems/shortest-subarray-with-or-at-least-k-ii

#include <vector>
#include <climits> // for INT_MAX
#include <algorithm> // for std::min

using namespace std;

class Solution {
public:
    int add(int x, int num, vector<int>& v) {
        int z = x;
        int y = num;
        for (int i = 0; i < 32; i++) {
            v[i] = ((z >> i) & 1) + ((y >> i) & 1);
        }
        return x | num;
    }

    int remove(int x, int num, vector<int>& v) {
        int z = x;
        for (int i = 0; i < 32; i++) {
            v[i] -= (z >> i) & 1;
        }
        int ans = 0;
        for (int i = 0; i < 32; i++) {
            ans += v[i] * (1 << (31 - i));
        }
        return ans;
    }

    int minimumSubarrayLength(vector<int>& nums, int k) {
        int i = 0, j = 0;
        int n = nums.size();
        int x = 0;
        int ans = INT_MAX;
        vector<int> v(32, 0);

        while (j < n) {
            x = add(x, nums[j], v);
            while (x >= k && j >= i) {
                ans = min(ans, j - i + 1);
                x = remove(x, nums[i], v);
                i++;
            }
            j++;
        }

        return (ans == INT_MAX) ? -1 : ans;
    }
};
