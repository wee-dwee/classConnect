// https://leetcode.com/problems/shortest-subarray-with-or-at-least-k-ii

class Solution {
public:
    int add(int x, int num,vector<int>& v) {
        int z = x;
        int y = num;
        
        vector<int> v1(32, 0);
        vector<int> v2(32, 0);
        for (int i = 31; i >= 0; i--) {
            v1[i] = z % 2;
            z/=2;
        }
        for (int i = 31; i >= 0; i--) {
            v2[i] = y%2;
            y/=2;
        }
        for (int i = 0; i < 32; i++) {
            v[i] = v1[i] + v2[i];
        }
        return x | num;
    }
    
    int remove(int x, int num, vector<int>& v) {
        int z = x;
        vector<int> v1(32, 0);
        for (int i = 31; i >= 0; i--) {
            v1[i] = z%2;
            z/= 2;
        }
        for (int i = 0; i < 32; i++) {
            v[i]-=v1[i];
        }
        int ans = 0;
        for (int i = 0; i < 32; i++) {
            ans += v[i] * (1 << (31 - i));
        }
        return ans;
    }
    
    int minimumSubarrayLength(vector<int>& nums, int k) {
        int i = 0, j = 0;
        int n = nums.size();
        int x = 0;
        int ans = INT_MAX;
        vector<int> v(32, 0);
        while (j < n) {
            x = add(x, nums[j], v);
            cout<<x<<endl;
            while (x >= k && j>=i) {
                ans = min(ans, j - i + 1);
                x = remove(x, nums[i], v);
                i++;
            }
            j++;
        }
        return (ans == INT_MAX) ? -1 : ans;
    }
};
