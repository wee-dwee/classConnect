// https://leetcode.com/problems/length-of-longest-subarray-with-at-most-k-frequency

class Solution {
public:
    int maxSubarrayLength(vector<int>& nums, int k) {
        unordered_map<int,int>m;
        int l = 0,r = 0;
        int ans = INT_MIN;
        int n = nums.size();
        while(r<n)
        {
            m[nums[r]]++;
            while(m[nums[l]]>k)
            {
                m[nums[l]]--;
                l++;
            }
            ans = max(ans,r-l+1);
            r++;
        }
        return ans;
    }
};