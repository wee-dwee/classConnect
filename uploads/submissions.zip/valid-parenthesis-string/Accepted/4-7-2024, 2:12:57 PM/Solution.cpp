// https://leetcode.com/problems/valid-parenthesis-string

class Solution {
public:
    bool checkValidString(string s) {
        int count1 = 0,count2 = 0;
        for(auto it:s)
        {
            if(it=='(')
            {
                count1++;
                count2++;
            }
            if(it==')')
            {
                count1--;
                count2--;
            }
            if(it=='*')
            {
                count1++;
                count2--;
            }
            if(count1<0)
            return false;
            count2 = max(count2,0);
        }
        return count2==0;

    }
};