// https://leetcode.com/problems/coloring-a-border

#include <vector>
#include <queue>
#include <set>

using namespace std;

class Solution {
public:
    vector<int> dx = {-1, 0, 1, 0};
    vector<int> dy = {0, -1, 0, 1};
    
    void bfs(int row, int col, vector<vector<int>>& grid, set<pair<int,int>>& border, int color, vector<vector<bool>>& visited) {
        int n = grid.size();
        int m = grid[0].size();
        
        queue<pair<int, int>> q;
        q.push({row, col});
        visited[row][col] = true;
        
        while (!q.empty()) {
            auto [x, y] = q.front();
            q.pop();
            
            bool isBorder = false;
            for (int i = 0; i < 4; ++i) {
                int newX = x + dx[i];
                int newY = y + dy[i];
                
                if (newX >= 0 && newX < n && newY >= 0 && newY < m) {
                    if (grid[newX][newY] != grid[x][y]) {
                        isBorder = true;
                    } else if (!visited[newX][newY]) {
                        q.push({newX, newY});
                        visited[newX][newY] = true;
                    }
                } else {
                    isBorder = true;
                }
            }
            
            if (isBorder) {
                border.insert({x, y});
            }
        }
    }
    
    vector<vector<int>> colorBorder(vector<vector<int>>& grid, int row, int col, int color) {
        int n = grid.size();
        int m = grid[0].size();
        
        set<pair<int,int>> border;
        vector<vector<bool>> visited(n, vector<bool>(m, false));
        
        bfs(row, col, grid, border, grid[row][col], visited);
        
        for (auto it : border) {
            int x = it.first;
            int y = it.second;
            grid[x][y] = color;
        }
        
        return grid;
    }
};
