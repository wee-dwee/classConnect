// https://leetcode.com/problems/non-decreasing-subsequences

class Solution {
public:
    void solve(int i,set<vector<int>>&ans,vector<int>&v,vector<int>&nums)
    {
        if(i>=nums.size())
        {
            return;
        }
        if(v.empty() || v.back()<=nums[i])
        {
            v.push_back(nums[i]);
            if(v.size()>=2)
            ans.insert(v);
            solve(i+1,ans,v,nums);
            v.pop_back();
        }
        solve(i+1,ans,v,nums);

    }
    vector<vector<int>> findSubsequences(vector<int>& nums) {
        set<vector<int>>ans;
        vector<int>v;
        int i = 0;
        solve(i,ans,v,nums);
        vector<vector<int>>ans2;
        for(auto it:ans)
        {
            ans2.push_back(it);
        }
        return ans2;
        
    }
};