// https://leetcode.com/problems/contiguous-array

class Solution {
public:
    int findMaxLength(vector<int>& nums) {
        int sum = 0;
        int maxi = 0;
        unordered_map<int,int>m;
        m[0] = -1;
        for(int i = 0;i<nums.size();i++)
        {
            sum+=(nums[i]==0)?-1:1;

            if(m.find(sum)!=m.end())
            {
                maxi = max(maxi,i-m[sum]);
            }
            
            m[sum] = i;
            
            
        }
        return maxi;
    }
};