// https://leetcode.com/problems/apply-operations-to-make-sum-of-array-greater-than-or-equal-to-k

class Solution {
public:
    int minOperations(int k) {
        int ans = INT_MAX;
        for(int x = 0;x*x<k;x++)
        {
            for(int y = 0;y*y<k;y++)
            {
                if((1+x)*y>=k)
                {
                    ans = min(ans,y-1+x);
                }
            }
        }
        return ans;
    }
};