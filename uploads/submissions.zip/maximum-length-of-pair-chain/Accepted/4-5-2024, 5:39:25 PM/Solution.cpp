// https://leetcode.com/problems/maximum-length-of-pair-chain

class Solution {
public:
    int solve(int curr, int prev, vector<vector<int>>& pairs, int n,vector<vector<int>>&dp) {
        
        if (curr >= n)
            return 0;   
        if(dp[prev+1][curr]!=-1)
        return dp[prev+1][curr];
        int include = INT_MIN;
        if (prev == -1 || (pairs[curr][0] > pairs[prev][1])) {
            include = 1 + solve(curr + 1, curr, pairs, n,dp);
        }
        int exclude = solve(curr + 1, prev, pairs, n,dp);
        return dp[prev+1][curr] = max(include, exclude);
    }

    int findLongestChain(vector<vector<int>>& pairs) {
        int n = pairs.size();
        if (n == 0)
            return 0;
        sort(pairs.begin(),pairs.end());
        vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
        return solve(0, -1, pairs, n,dp);
    }
};
