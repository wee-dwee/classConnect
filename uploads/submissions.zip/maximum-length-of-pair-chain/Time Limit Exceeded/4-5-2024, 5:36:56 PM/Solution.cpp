// https://leetcode.com/problems/maximum-length-of-pair-chain

class Solution {
public:
    int solve(int curr, int prev, vector<vector<int>>& pairs, int n) {
        
        if (curr >= n)
            return 0;

        int include = INT_MIN;
        if (prev == -1 || (pairs[curr][0] > pairs[prev][1])) {
            include = 1 + solve(curr + 1, curr, pairs, n);
        }
        int exclude = solve(curr + 1, prev, pairs, n);
        return max(include, exclude);
    }

    int findLongestChain(vector<vector<int>>& pairs) {
        int n = pairs.size();
        if (n == 0)
            return 0;
        sort(pairs.begin(),pairs.end());
        return solve(0, -1, pairs, n);
    }
};
