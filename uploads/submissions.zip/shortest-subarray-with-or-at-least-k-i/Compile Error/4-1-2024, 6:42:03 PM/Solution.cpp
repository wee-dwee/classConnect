// https://leetcode.com/problems/shortest-subarray-with-or-at-least-k-i

class Solution {
public:
    int minimumSubarrayLength(vector<int>& nums, int k) {
        int count = 0;
        for(int i = 0;i<nums.size();i++)
        {
            int x = 0;
            int count2 = 0;
            for(int j = i+1;j<nums.size();j++)
            {
                x^=nums[j];
                
            }
            
        }
    }
};