// https://leetcode.com/problems/shortest-subarray-with-or-at-least-k-i

class Solution {
public:
    int minimumSubarrayLength(vector<int>& nums, int k) {
        int ans = INT_MAX;
        for(int i = 0;i<nums.size();i++)
        {
            int x = 0;
            for(int j = i;j<nums.size();j++)
            {
                x|=nums[j];
                if(x>=k)
                {
                    ans = min(j-i+1,ans);
                    break;
                }
            }
            
            
        }
        return ans==INT_MAX?-1:ans;
    }
};