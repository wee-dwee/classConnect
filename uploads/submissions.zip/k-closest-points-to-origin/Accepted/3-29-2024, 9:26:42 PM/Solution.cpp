// https://leetcode.com/problems/k-closest-points-to-origin

struct cmp {
    bool operator()(const pair<int, int>& a, const pair<int, int>& b) const {
        
        return (a.first*a.first+a.second*a.second)<(b.first*b.first+b.second*b.second);
    }
};
class Solution {
public:

    vector<vector<int>> kClosest(vector<vector<int>>& points, int k) {
        priority_queue<pair<int,int>,vector<pair<int,int>>,cmp>pq;
        for(int i = 0;i<points.size();i++)
        {
            pq.push({points[i][0],points[i][1]});
            if(pq.size()>k){
                pq.pop();
            }
        }
        vector<vector<int>>ans;
        while(!pq.empty())
        {
            pair<int,int>p = pq.top();
            vector<int>a = {p.first,p.second};
            ans.push_back(a);
            pq.pop();
        }
        return ans;
    }
};