// https://leetcode.com/problems/lemonade-change

class Solution {
public:
    bool lemonadeChange(vector<int>& bills) {
        unordered_map<int,int>m;
        for(int i = 0;i<bills.size();i++)
        {
            m[bills[i]]++;
            if(bills[i]==10)
            {
                if(m[5]==0)
                return false;
                m[5]--;
            }
            if(bills[i]==20)
            {
                if(m[10]==0)
                return false;
                if(m[5]==0)
                return false;
                m[10]--;
                m[5]--;
            }
        }
        return true;
    }
};