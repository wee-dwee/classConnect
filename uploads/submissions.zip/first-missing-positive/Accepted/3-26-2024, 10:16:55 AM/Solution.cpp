// https://leetcode.com/problems/first-missing-positive

class Solution {
public:
    int firstMissingPositive(vector<int>& nums) {
        unordered_set<int>s;
        for(auto it:nums)
        {
            s.insert(it);
        }
        int maxi = INT_MAX;
        for(auto it:s)
        {
            maxi = max(maxi,it);
        }
        if(maxi<0)
        return 0;
        for(int i = 1;i<maxi;i++)
        {
            if(s.find(i)==s.end())
            return i;
        }
        return maxi+1;
        
    }
};