// https://leetcode.com/problems/gray-code

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    
    vector<string>solve(int n)
    {
        if(n==1)
        return {"0","1"};
        
        vector<string>ans1 = solve(n-1);
        vector<string>ans2;
        for(auto it:ans1)
        {
            string s = "0";
            s.append(it);
            ans2.push_back(s);
        }
        reverse(ans1.begin(),ans1.end());
        for(auto it:ans1)
        {
            string s = "1";
            s.append(it);
            ans2.push_back(s);
        }
        return ans2;
    }
    
    
    vector<int> grayCode(int n) {
        vector<string>v = solve(n);
        vector<int>ans;
        for(auto it:v)
        {
            ans.push_back(stoi(it, 0, 2));
        }
        return ans;
    }
};

