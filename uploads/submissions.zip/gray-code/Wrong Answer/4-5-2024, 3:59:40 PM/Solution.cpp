// https://leetcode.com/problems/gray-code

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    void change(string &s,int i) {
        if (s[i] == '1')
            s[i] = '0';
        else
            s[i] = '1';
    }

    void solve(int i, unordered_map<string,bool> &visited, string &s, vector<string> &ans) {
        if (i == s.length()) {
            return;
        }
        
        for (int j = 0; j < s.length(); j++) {
            if (visited[s])
                continue;

            ans.push_back(s);
            visited[s] = true;
            change(s, j);
            solve(0, visited, s, ans);
            change(s,j);
        }
    }
    void solve2(int i,unordered_map<string,bool> &visited,string &s, vector<string> &ans)
    {
        if (i == 0) {
            return;
        }
        for (int j = s.length()-1; j >= 0; j--) {
            if (visited[s])
                continue;

            ans.push_back(s);
            visited[s] = true;
            change(s, j);
            solve(s.length()-1, visited, s, ans);
            change(s,j);
        }
    }
    vector<int> grayCode(int n) {
        string s = "";
        for (int i = 0; i < n; i++) {
            s.push_back('0');
        }
        vector<string> ans;
        vector<string> ans2;
        unordered_map<string, bool> visited;
        unordered_map<string, bool> visited2;
        solve(0, visited, s, ans);
        solve2(n-1,visited2,s,ans2);
        reverse(ans2.begin(),ans2.end());
        for(auto it:ans2)
        {
            ans.push_back(it);
        }
        unordered_set<string>se;
        vector<int>act;
        for(auto it:ans)
        se.insert(it);
        for(auto it:se)
        {
            act.push_back(stoi(it, 0, 2));
        }
        int last = act.back();
        act.pop_back();
        act.insert(act.begin(), last);
        return act;
    }
};


