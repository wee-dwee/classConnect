// https://leetcode.com/problems/gray-code

class Solution {
public:
    void change(string &s,int i)
    {
        if(s[i]=='1')
        s[i] = '0';
        if(s[i]=='0')
        s[i] = '1';
    }
    void solve(int i,unordered_map<string,bool>&visited,string &s,vector<string>&ans)
    {
        if(i==s.length())
        {
            return;
        }
        for(int j = 0;j<s.length();j++)
        {
            if(visited[s])
            continue;
            
            change(s,i);
            
            visited[s] = true;
            solve(0,visited,s,ans);
            change(s,i);
            visited[s] = false;
        }
    }
    vector<int> grayCode(int n) {
        string s = "";
        for(int i = 0;i<n;i++)
        {
            s.push_back('0');
        }
        vector<string>ans;
        int i = 0;
        unordered_map<string,bool>visited;
        solve(0,visited,s,ans);
        for(auto it:ans)
        {
            cout<<it<<endl;
        }
        return {};
    }
};