// https://leetcode.com/problems/gray-code

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    void change(string &s,int i) {
        if (s[i] == '1')
            s[i] = '0';
        else
            s[i] = '1';
    }

    void solve(int i, unordered_map<string,bool> &visited, string &s, vector<string> &ans) {
        if (i == s.length()) {
            return;
        }
        
        for (int j = 0; j < s.length(); j++) {
            if (visited[s])
                continue;

            ans.push_back(s);
            visited[s] = true;
            change(s, j);
            solve(0, visited, s, ans);
            change(s,j);
        }
    }
    vector<int> grayCode(int n) {
        string s = "";
        for (int i = 0; i < n; i++) {
            s.push_back('0');
        }
        vector<string> ans;
        unordered_map<string, bool> visited;
        
        solve(0, visited, s, ans);
        solve2(n-1,visited2,s,ans);
        for(auto it:ans)
        cout<<it<<endl;
        return {};
    }
};


