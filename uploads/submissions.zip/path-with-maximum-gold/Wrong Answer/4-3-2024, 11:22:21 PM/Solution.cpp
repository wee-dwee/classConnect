// https://leetcode.com/problems/path-with-maximum-gold

class Solution {
public:
    void dfs(int i,int j,vector<vector<int>>&grid,int &sum,vector<vector<int>>&visited)
    {
        
        return;




    }
    int getMaximumGold(vector<vector<int>>& grid) {
        int n = 0,m = grid[0].size();
        int ans = INT_MIN;
        vector<vector<int>>visited(n,vector<int>(m,false));
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<m;j++)
            {
                if(grid[i][j]!=0)
                {
                    int sum = grid[i][j];
                    dfs(i,j,grid,sum,visited);
                    ans = max(ans,sum);
                }
                for(int i = 0;i<n;i++)
                {
                    for(int j = 0;j<m;j++)
                    {
                        visited[i][j] = false;
                    }
                }
            }
        }
        return ans;
    }
};