// https://leetcode.com/problems/path-with-maximum-gold

class Solution {
public:
    vector<int>dx = {-1,0,1,0};
    vector<int>dy = {0,1,0,-1};
    int dfs(int i,int j,vector<vector<int>>&grid)
    {
        if(i==grid.size()||i<0||j==grid[0].size()||j<0)
        {
            return 0;
        }
        if(grid[i][j]==0)
        return 0;
        
        int original = grid[i][j];
        

        grid[i][j] = 0;
        for(int k = 0;k<4;k++)
        {
            int newX = i+dx[k];
            int newY = j+dy[k];
            ans = max(ans,dfs(newX,newY,grid));
        }
        grid[i][j] = original;

        return ans+grid[i][j];
    }
    int getMaximumGold(vector<vector<int>>& grid) {
        int n = 0,m = grid[0].size();
        int ans = 0;
       
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<m;j++)
            {
                if(grid[i][j]!=0)
                {
                    int sum = dfs(i,j,grid);
                    ans = max(ans,sum);
                }
            }
        }
        return ans;
    }
};