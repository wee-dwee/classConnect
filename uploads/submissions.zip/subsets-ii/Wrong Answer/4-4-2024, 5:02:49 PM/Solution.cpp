// https://leetcode.com/problems/subsets-ii

class Solution {
public:
    void solve(set<vector<int>>&out,vector<int>&ans,int i,vector<int>& nums)
    {
        if(i==nums.size())
        {
            out.insert(ans);
            return;
        }
        ans.push_back(nums[i]);
        solve(out,ans,i+1,nums);
        ans.pop_back();
        solve(out,ans,i+1,nums);
    }
    vector<vector<int>> subsetsWithDup(vector<int>& nums) {
        set<vector<int>>out;
        vector<int>ans;
        int i=0;
        solve(out,ans,i,nums);
        
        vector<vector<int>>ans2;
        for(auto it:out)
        {
            ans2.push_back(it);
        }
        return ans2;
    }
};