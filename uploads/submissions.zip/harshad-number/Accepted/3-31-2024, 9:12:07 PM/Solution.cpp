// https://leetcode.com/problems/harshad-number

class Solution {
public:
    bool harshad(int x) 
    {
        int z  = x;
        int sum = 0;
        while(z!=0)
        {
            sum+=z%10;
            z/=10;
        }
        if(x%sum==0)
            return true;
        return false;
    }
    
    int sum(int x)
    {
        int z = x;
        int sum = 0;
        while(z!=0)
        {
            sum+=z%10;
            z/=10;
        }
        return sum;
    }
    int sumOfTheDigitsOfHarshadNumber(int x) {
        if(harshad(x))
        {
            return sum(x);
        }
        else
        {
            return -1;
        }
    }
};