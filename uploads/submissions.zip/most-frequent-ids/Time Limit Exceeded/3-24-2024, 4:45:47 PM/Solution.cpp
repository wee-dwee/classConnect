// https://leetcode.com/problems/most-frequent-ids


class Solution {
public:
    vector<long long> mostFrequentIDs(vector<int>& nums, vector<int>& freq) {
        unordered_map<int,int>m;
        int n = nums.size();
        vector<long long>v(n);
        for(int i = 0;i<n;i++)
        {
            m[nums[i]]+=freq[i];
            int maxi = INT_MIN;
            for(auto it:m)
            {
                maxi = max(maxi,it.second);
            }
            v[i] = maxi;
        }
        return v;
    }
};