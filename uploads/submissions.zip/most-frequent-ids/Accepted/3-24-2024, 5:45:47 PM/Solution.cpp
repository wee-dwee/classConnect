// https://leetcode.com/problems/most-frequent-ids

class Solution {
public:
    vector<long long> mostFrequentIDs(vector<int>& nums, vector<int>& freq) {
        map<int,long long> count; 
        set<pair<long long,int>> st; 
        vector<long long> ans;

        for(int i=0; i<nums.size(); i++) {
            st.erase({count[nums[i]],nums[i]}); 
            count[nums[i]] += freq[i];          
            st.insert({count[nums[i]],nums[i]}); 
            ans.push_back((*st.rbegin()).first);
        }
     return ans;
    }
};