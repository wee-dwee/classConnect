// https://leetcode.com/problems/most-frequent-ids


class Solution {
public:
    vector<long long> mostFrequentIDs(vector<int>& nums, vector<int>& freq) {
        unordered_map<long long,long long>m;
        map<long long,long long>m2;
        long long n = nums.size();
        vector<long long>v(n);
        for(long long i = 0;i<n;i++)
        {
            if(m2.find(m[nums[i]])!=m2.end())
            {
                m2.erase(m[nums[i]]);
            }
            m[nums[i]]+=freq[i];
            m2[m[nums[i]]] = nums[i];
            
           auto lastElement = m2.rbegin();
           v[i] = lastElement->first;
           
        }
        //reverse(v.begin(),v.end());
        return v;
    }
};