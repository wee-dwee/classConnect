// https://leetcode.com/problems/most-frequent-ids


class Solution {
public:
    vector<long long> mostFrequentIDs(vector<int>& nums, vector<int>& freq) {
        unordered_map<int,int>m;
        map<int,int>m2;
        int n = nums.size();
        vector<long long>v(n);
        for(int i = 0;i<n;i++)
        {
            if(m2.find(m[nums[i]])!=m2.end())
            {
                m2.erase(m[nums[i]]);
            }
            m[nums[i]]+=freq[i];
            m2[m[nums[i]]] = nums[i];
            
           auto lastElement = m2.rbegin();
           v[i] = lastElement->first;
        }
        //reverse(v.begin(),v.end());
        return v;
    }
};