// https://leetcode.com/problems/count-subarrays-with-score-less-than-k

class Solution {
public:
    long long countSubarrays(vector<int>& nums, long long k) {
        int length = 0;
        int prod = 1;
        int l = 0,r = 0;
        int n = nums.size();
        int count = 0;
        while(r<n)
        {
            prod*=nums[r];
            length = r-l+1;
            int score = prod*length;
            while(score>=k)
            {
                prod = prod/nums[l];
                length--;
                score = prod*length;
                l++;
            }
            count+=1+r-l;
            r++;
        }
        return count-1;
    }
};