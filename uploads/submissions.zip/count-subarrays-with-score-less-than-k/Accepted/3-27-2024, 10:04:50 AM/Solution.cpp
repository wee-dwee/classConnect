// https://leetcode.com/problems/count-subarrays-with-score-less-than-k

class Solution {
public:
    long long countSubarrays(vector<int>& nums, long long k) {
        long long length = 0;
        long long sum = 0;
        long long l = 0,r = 0;
        long long n = nums.size();
        long long count = 0;
        while(r<n)
        {
            sum+=nums[r];
            length = r-l+1;
            long long score = sum*length;
            while(score>=k)
            {
                sum-=nums[l];
                length--;
                score = sum*length;
                l++;
            }
            count+=1+r-l;
            r++;
        }
        return count;
    }
};