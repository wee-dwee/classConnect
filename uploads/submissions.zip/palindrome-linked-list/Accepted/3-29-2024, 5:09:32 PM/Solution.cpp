// https://leetcode.com/problems/palindrome-linked-list

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* reverse(ListNode* head)
    {
        ListNode* next = NULL;
        ListNode* prev = NULL;
        ListNode* curr = head;
        while(curr!=NULL)
        {
            next = curr->next;
            curr->next = prev;
            prev = curr;
            curr = next;
        }
        return prev;
    }
    bool isPalindrome(ListNode* head) {
        vector<int>v;
        ListNode* temp2 = head;
        while(temp2!=NULL)
        {
            v.push_back(temp2->val);
            temp2=temp2->next;
        }
        ListNode* rev = reverse(head);
        ListNode* temp = rev;
        vector<int>v2;
        while(temp!=NULL)
        {   
            v2.push_back(temp->val);
            temp=temp->next;
        }
        return v==v2;
    }
};