// https://leetcode.com/problems/house-robber-iii

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    int rob(TreeNode* root) {
        queue<TreeNode*>q;
        q.push(root);
        int sum1 = 0,sum2 = 0;
        vector<vector<int>>ans;
        while(!q.empty())
        {
            int s = q.size();
            vector<int>v(s);
            for(int i = 0;i<s;i++)
            {
                TreeNode* temp = q.front();
                q.pop();
                v[i] = temp->val;
                if(temp->left)
                q.push(temp->left);
                if(temp->right)
                q.push(temp->right);
            }
            ans.push_back(v);
        }
        int totSum1 = 0,totSum2 = 0; 
        for(int i = 0;i<ans.size();i++)
        {
            int sum = 0;
            for(int j = 0;j<ans[i].size();j++)
            {
                sum+=ans[i][j];
            }
            if(i%2==0)
            {
                totSum1+=sum;
            }
            if(i%2==1)
            {
                totSum2+=sum;
            }
        }
        return max(totSum1,totSum2);
    }
};