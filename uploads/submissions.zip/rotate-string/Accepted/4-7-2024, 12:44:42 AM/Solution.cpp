// https://leetcode.com/problems/rotate-string

#include <string>
using namespace std;

class Solution {
public:
    bool rotateString(const string& s, const string& goal) {
        if (s.length() != goal.length())
            return false;

        string s1 = s + s;
        if(s1.find(goal)==-1)
        return false;
        return true;
    }
};
