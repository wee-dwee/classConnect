// https://leetcode.com/problems/rotate-string

class Solution {
public:
    bool rotateString(string s, string goal) {
        string s1 = s+s;
        int i = 0,j = 0;
        while(i<s1.length() && j<goal.length())
        {
            if(s1[i]==goal[j])
            {
                i++;
                j++;
            }
            if(j==goal.length()-1 && s1[i]==goal[j])
            {
                return true;
            }
            if(s1[i]!=goal[j]){
                j=0;
                i++;
            }
        }
        return false;
    }
};