// https://leetcode.com/problems/rotate-string

#include <string>
using namespace std;

class Solution {
public:
    bool rotateString(const string& s, const string& goal) {
        if (s.length() != goal.length())
            return false;

        string s1 = s + s;
        int i = 0, j = 0;
        while (i < s1.length() && j < goal.length()) {
            if (s1[i] == goal[j]) {
                i++;
                j++;
            } else {
                
                j = 0;
                i++;
            }
        }
        return j == goal.length();
    }
};
