// https://leetcode.com/problems/find-the-index-of-the-first-occurrence-in-a-string

class Solution {
public:
    int strStr(std::string s1, std::string s2) {
        int i = 0, j = 0;
        int n = s1.size(), m = s2.size();
        
        if (m == 0) return 0;
        if (n == 0 || m > n) return -1; 
        while (i < n && j<m) {
            if (s1[i] == s2[j]) {
                if (j == m - 1) {
                    return i - m + 1; 
                }
                i++;
                j++;
            } else {
                j=0;
                i++;
            }
        }
        
        return -1; 
    }
};