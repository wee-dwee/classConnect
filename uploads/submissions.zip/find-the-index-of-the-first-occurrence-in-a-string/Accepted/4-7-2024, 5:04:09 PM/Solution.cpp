// https://leetcode.com/problems/find-the-index-of-the-first-occurrence-in-a-string

class Solution {
public:
    int strStr(string s1, string s2) {
        if(s1.find(s2)<s1.size())
                return s1.find(s2);
           
        return -1;
    }
};
