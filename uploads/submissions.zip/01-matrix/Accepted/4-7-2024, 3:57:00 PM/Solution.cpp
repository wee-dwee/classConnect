// https://leetcode.com/problems/01-matrix

class Solution {
public:
    

    vector<vector<int>> updateMatrix(vector<vector<int>>& mat) {
        int n = mat.size(),m = mat[0].size();
        vector<vector<int>>dist(n,vector<int>(m,INT_MAX));
        queue<pair<int,int>>q;
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<m;j++)
            {
                if(mat[i][j]==0)
                {
                    dist[i][j] = 0;
                    q.push({i,j});
                }
            }
        }
        vector<int>dx = {-1,0,1,0};
        vector<int>dy = {0,1,0,-1};
        while(!q.empty())
        {
            pair<int,int>p = q.front();
            q.pop();
            for(int i = 0;i<4;i++)
            {
                int newX = p.first+dx[i];
                int newY = p.second+dy[i];
                if(newX>=0&& newX<n && newY>=0 && newY<m)
                {
                    if(dist[newX][newY]>1+dist[p.first][p.second])
                    {
                        dist[newX][newY]= 1+dist[p.first][p.second];
                        q.push({newX,newY});
                    }
                }
            }
        }
        return dist;
    }
};