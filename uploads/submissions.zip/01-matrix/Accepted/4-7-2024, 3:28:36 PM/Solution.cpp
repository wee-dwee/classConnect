// https://leetcode.com/problems/01-matrix

class Solution {
public:
    vector<vector<int>> updateMatrix(vector<vector<int>>& matrix) {
        int rowNum = matrix.size();
        int colLen = matrix[0].size();

        for (int rows = 0; rows < rowNum; rows++) {
            for (int col = 0 ; col < colLen ; col++) {
                if (matrix[rows][col] == 0) continue;
                int top = (rows - 1 >= 0) ? matrix[rows - 1][col] : 10000;
                int left = (col - 1 >= 0) ? matrix[rows][col - 1] : 10000;
                matrix[rows][col] = min(top, left) + 1;
            }
        }

        for (int row = rowNum - 1; row >= 0; row--) {
            for (int col = colLen - 1; col >= 0; col--) {
                if (matrix[row][col] == 0) continue;
                int bottom = (row + 1 <= rowNum - 1) ? matrix[row + 1][col] : 10000; 
                int right = (col + 1 <= colLen - 1) ? matrix[row][col + 1] : 10000;
                matrix[row][col] = min(matrix[row][col], min(bottom, right) + 1);
            }
        }
        return matrix;
    }
};
