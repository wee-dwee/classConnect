// https://leetcode.com/problems/01-matrix

class Solution {
public:
    int dfs(int i, int j, vector<vector<int>>& mat, vector<vector<int>>& dp) {
        if (i < 0 || i >= mat.size() || j < 0 || j >= mat[0].size() || mat[i][j] == 2)
            return 10000;
        if (mat[i][j] == 0)
            return 0;
        if (dp[i][j]!=10000)
            return dp[i][j];

        mat[i][j] = 2;
        int x1 = dfs(i + 1, j, mat, dp);
        int x2 = dfs(i - 1, j, mat, dp);
        int x3 = dfs(i, j + 1, mat, dp);
        int x4 = dfs(i, j - 1, mat, dp);
        mat[i][j] = 1;
        int mini = min(x1, min(x2, min(x3, x4)));
        return dp[i][j] = 1 + mini;
    }

    vector<vector<int>> updateMatrix(vector<vector<int>>& mat) {
        vector<vector<int>> v = mat;
        int n = mat.size(), m = mat[0].size();
        vector<vector<int>> dp(n, vector<int>(m, 10000));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                if (mat[i][j] == 1) {
                    v[i][j] = dfs(i, j, v, dp);
                }
            }
        }
        return v;
    }
};