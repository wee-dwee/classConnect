// https://leetcode.com/problems/product-of-array-except-self

class Solution {
public:
    vector<int> productExceptSelf(vector<int>& nums) {
        int prod = 1;
        for(auto it:nums)
        {
            prod*=it;
        }
        vector<int>ans;
        if(prod!=0)
        {
            for(auto it:nums)
            {
                ans.push_back(prod/it);
            }   
        }
        else
        {
            int zCount = 0;
            for(auto it:nums)
            {
                if(it==0)
                zCount++;
            }
            if(zCount > 1)
            {
                for(auto it:nums)
                {
                    ans.push_back(0);
                }
            }
            else if(zCount==1){
                for(auto it:nums)
                {
                    ans.push_back(0);
                }
                int prod = 1;
                for(int i = 0;i<nums.size();i++)
                {
                    if(nums[i]==0)
                    continue;
                    prod*=nums[i];
                    
                }
                int i=0;
                for( i=0;i<nums.size();i++)
                {
                    if(nums[i]==0)
                    break;
                }
                ans[i] = prod;
            }
        }
        return ans;
    }
};