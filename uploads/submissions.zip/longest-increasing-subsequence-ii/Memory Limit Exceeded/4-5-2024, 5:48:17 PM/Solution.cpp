// https://leetcode.com/problems/longest-increasing-subsequence-ii

class Solution {
public:
    int solve(int prev,int curr,vector<int>& nums,vector<vector<int>>&dp,int k)
    {
        if(curr==nums.size())
        return 0;
        if(dp[curr][prev+1]!=-1)
        return dp[curr][prev+1];

        int include = INT_MIN;
        int exclude = INT_MIN;
        if(prev==-1||nums[curr]>nums[prev] && nums[curr]-nums[prev]<=k)
        {
            include = 1+solve(curr,curr+1,nums,dp,k);
        }
        exclude = solve(prev,curr+1,nums,dp,k);
        return dp[curr][prev+1] = max(include,exclude);
    }
    int lengthOfLIS(vector<int>& nums,int k) {
        int n = nums.size();
        vector<vector<int>>dp(n+1,vector<int>(n+1,0));
        for(int curr = n-1;curr>=0;curr--)
        {
            for(int prev = curr-1;prev>=-1;prev--)
            {
                int include = INT_MIN;
                int exclude =  dp[curr+1][prev+1];
                if(prev==-1||nums[curr]>nums[prev] && (nums[curr]-nums[prev]<=k))
                {
                    include = 1+dp[curr+1][curr+1];
                }
                dp[curr][prev+1] = max(include,exclude);
            }
        }
        return dp[0][0];
    }
};