// https://leetcode.com/problems/jump-game

class Solution {
public:
    bool canJump(vector<int>& nums) {
        int range = 0;
        for(int i = 0;i<nums.size();i++)
        {
            if(range>=nums.size()-1)
            return true;
            if(range<=i && nums[i]==0)
            return false;
            range = max(range,i+nums[i]);
        }
        
        return false;
    }
};