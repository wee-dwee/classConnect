// https://leetcode.com/problems/minimum-remove-to-make-valid-parentheses

class Solution {
public:
    bool isAlpha(char a)
    {
        if(a>='a' && a<='z')
        return true;
        return false;
    }
    string minRemoveToMakeValid(string s) {
        stack<pair<char,int>>st;
        vector<pair<char,int>>v;
        string ans = "";
        for(int i = 0;i<s.length();i++)
        {
            if(isAlpha(s[i]))
            {   
                continue;
            }
            else if(s[i]=='(')
            {
                st.push({'(',i});
            }
            if(st.empty() && s[i]==')')
            {
                v.push_back({')',i});
            }
            if(!st.empty() && s[i]==')')
            {
                st.pop();
            }
        }
        while(!st.empty())
        {
            v.push_back(st.top());
            st.pop();
        }
        unordered_set<int>se;
        for(auto it:v)
        {
            se.insert(it.second);
        }
        for(int i = 0;i<s.length();i++)
        {
            if(se.find(i)!=se.end())
            {
                continue;
            }
            else
            {
                ans.push_back(s[i]);
            }
        }

        return ans;
    }
};