// https://leetcode.com/problems/longest-consecutive-sequence

class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        sort(nums.begin(),nums.end());
        int n = nums.size();
        vector<vector<int>>dp(n+1,vector<int>(n+1,0));
        for(int curr = n-1;curr>=0;curr--)
        {
            for(int prev = curr-1;prev>=-1;prev--)
            {
                int include = INT_MIN;
                int exclude =  dp[curr+1][prev+1];
                if(prev==-1||nums[curr]==nums[prev]+1)
                {
                    include = 1+dp[curr+1][curr+1];
                }
                dp[curr][prev+1] = max(include,exclude);
            }
        }
        return dp[0][0];
    }
};