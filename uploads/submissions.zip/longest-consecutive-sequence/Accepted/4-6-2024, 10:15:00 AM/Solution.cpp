// https://leetcode.com/problems/longest-consecutive-sequence

#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;

class Solution {
public:
    int longestConsecutive(vector<int>& nums) {
        if (nums.empty()) return 0;
        
        sort(nums.begin(), nums.end());
        int n = nums.size();
        unordered_map<int, int> dp;
        int maxLen = 1;

        for (int i = 0; i < n; ++i) {
            if (dp.find(nums[i] - 1) != dp.end()) {
                dp[nums[i]] = dp[nums[i] - 1] + 1;
                maxLen = max(maxLen, dp[nums[i]]);
            } else {
                dp[nums[i]] = 1;
            }
        }

        return maxLen;
    }
};
