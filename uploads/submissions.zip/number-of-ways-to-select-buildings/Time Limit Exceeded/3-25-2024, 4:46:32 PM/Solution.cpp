// https://leetcode.com/problems/number-of-ways-to-select-buildings

class Solution {
public:
    void solve(vector<vector<char>>&out,vector<char>&ans,string s,int i,int prev)
    {
        if(ans.size()==3)
        {
            out.push_back(ans);
            return ;
        }
            
        if(i==s.length())
            return;
        
        if(prev == -1 || (s[i]!=s[prev]) )
        {
            ans.push_back(s[i]);
            solve(out,ans,s,i+1,i);
            ans.pop_back();
            solve(out,ans,s,i+1,prev);
        }
        else
        {
            solve(out,ans,s,i+1,prev);
        }
    }
    long long numberOfWays(string s) {
        vector<vector<char>>out;
        vector<char>ans;
        int i = 0;
        int prev = -1;
        solve(out,ans,s,0,-1);
        return out.size();
    }
};