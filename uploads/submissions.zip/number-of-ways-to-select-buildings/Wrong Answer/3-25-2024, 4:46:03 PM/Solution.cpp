// https://leetcode.com/problems/number-of-ways-to-select-buildings

class Solution {
public:
    void solve(vector<vector<char>>&out,vector<char>&ans,string s,int i,int prev,vector<vector<int>>&dp)
    {
        if(ans.size()==3)
        {
            out.push_back(ans);
            return ;
        }
            
        if(i==s.length())
            return;
        
        if(dp[i][prev+1]!=-1)
        return ;

        if(prev == -1 || (s[i]!=s[prev]) )
        {
            ans.push_back(s[i]);
            solve(out,ans,s,i+1,i,dp);
            dp[i+1][i] = true;
            ans.pop_back();
            solve(out,ans,s,i+1,prev,dp);
            dp[i+1][prev+1]=  true;
        }
        else
        {
            solve(out,ans,s,i+1,prev,dp);
            dp[i+1][prev] = true;
        }
    }
    long long numberOfWays(string s) {
        vector<vector<char>>out;
        vector<char>ans;
        int i = 0;
        int prev = -1;
        vector<vector<int>>dp(s.length()+1,vector<int>(s.length()+1,-1));
        solve(out,ans,s,0,-1,dp);
        
        return out.size();
    }
};