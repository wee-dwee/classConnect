// https://leetcode.com/problems/find-all-duplicates-in-an-array

#include<bits/stdc++.h>
class Solution {
public:
    vector<int> findDuplicates(vector<int>& nums) {
        map<int,int>m;
        int n=nums.size();
        for(int i=0;i<n;i++)
        {
            m[nums[i]]++;
        }
        vector<int>v;
        for(auto it:m)
        {
            if(it.second>1)
            v.push_back(it.first);
        }
        return v;
    }
};