// https://leetcode.com/problems/water-bottles-ii

class Solution {
public:
    int maxBottlesDrunk(int numBottles, int numExchange) {
        int x = numBottles;
        int y = numExchange;
        int emptyBottles = 0;
        int bottlesDrunk = 0;
        
        emptyBottles = x;
        x = 0;
        bottlesDrunk = emptyBottles;
        
        
        while(y<=emptyBottles)
        {
            emptyBottles-=y;
            y++;
            x++;
            if(y>emptyBottles)
            {
                emptyBottles+=x;
                bottlesDrunk+=x;
                x=0;
            }
        }
        return bottlesDrunk;
    }
};