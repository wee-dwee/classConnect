// https://leetcode.com/problems/replace-question-marks-in-string-to-minimize-its-value

class Solution {
public:
    string minimizeStringValue(string s) {
        map<char,int>m;
        for(int i =  0;i<26;i++)
        {
            m.insert({i+'a',0});
        }
        int i = 0;
        if(s[0]=='?')
        {
            s[0] = 'a';
            m['a']++;
            i++;
        }
        for(;i<s.length();i++)
        {
            if(s[i]=='?')
            {
                int mini = 0;
                for(auto jt:m)
                {
                    mini = min(mini,jt.second);
                }
                char c;
                for (auto jt = m.begin(); jt != m.end(); ++jt) {
                    if (jt->second == mini) {
                    c = jt->first;
                    break;
                    }
            }
                m[c]++;
                s[i] = c;
            }
            else
            {
                m[s[i]]++;
            }
        }
        return s;
    }
};