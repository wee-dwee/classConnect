// https://leetcode.com/problems/maximum-length-substring-with-two-occurrences

int max(int a, int b) {
    return (a > b) ? a : b;
}

class Solution {
public:
    int maximumLengthSubstring(string s) {
        unordered_map<char, int> m;
        
        
        int maxi = INT_MIN;
        int n = s.length();
        for(int i = 0;i<n;i++)
        {
            for(int j = i+1;j<n;j++)
            {
                string sub = s.substr(i,j-i+1);
                int count = 0;
                for(auto it:sub)
                {
                    m[it]++;
                }
                for(auto it:sub)
                {
                    if(m[it]<=2)
                        count++;
                }
                if(count == sub.length())
                {
                    maxi = max(maxi,count);
                }
                m.clear();
            }
        }
        return maxi;
    }
};


