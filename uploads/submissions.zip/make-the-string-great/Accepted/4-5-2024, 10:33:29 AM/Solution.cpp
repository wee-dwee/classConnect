// https://leetcode.com/problems/make-the-string-great

class Solution {
public:
    bool check(char c1,char c2)
    {
        if(islower(c1) && isupper(c2) && tolower(c1)==tolower(c2))
        return true;
        if(isupper(c1) && islower(c2) && tolower(c1)==tolower(c2))
        return true;
        return false;
    }
    string makeGood(string s) {
        stack<char>st;
        for(int i = 0;i<s.length();i++)
        {
            if(!st.empty() && check(s[i],st.top()))
            {
                st.pop();
            }
            else
            {
                st.push(s[i]);
            }
        }
        string ans = "";
        while(!st.empty())
        {
            ans.push_back(st.top());
            st.pop();
        }
        reverse(ans.begin(),ans.end());
        return ans;
    }
};