// https://leetcode.com/problems/flood-fill

class Solution {
public: 
    vector<int>dx = {-1,0,1,0};
    vector<int>dy = {0,1,0,-1};
    void bfs(int sr,int sc,int color,vector<vector<int>>&image,vector<vector<bool>>&visited,int startColor)
    {
        queue<pair<int,int>>q;
        q.push({sr,sc});
        visited[sr][sc] = true;
        image[sr][sc] = color;
        while(!q.empty())
        {
            pair<int,int>p = q.front();
            q.pop();
            for(int i = 0;i<4;i++)
            {
                int newX = dx[i]+p.first;
                int newY = dy[i]+p.second;
                if(newX<image.size() && newX>=0 && newY<image[0].size()&& newY>=0 && !visited[newX][newY] && image[newX][newY]==startColor)
                {
                    visited[newX][newY] = true;
                    image[newX][newY] = color;
                    q.push({newX,newY});
                }
            }
        }
    }
    vector<vector<int>> floodFill(vector<vector<int>>& image, int sr, int sc, int color) {
        int startColor = image[sr][sc];
        int n = image.size(),m  = image[0].size();
        vector<vector<bool>>visited(n,vector<bool>(m,false));
        bfs(sr,sc,color,image,visited,startColor);
        if(startColor == color)
        return image;

        return image;
    }
};