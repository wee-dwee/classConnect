// https://leetcode.com/problems/flood-fill

class Solution {
public:
    vector<int>dx = {-1,0,1,0};
    vector<int>dy = {0,1,0,-1};
    void bfs(int sr,int sc,int color,vector<vector<int>>&image,vector<vector<bool>>&visited,vector<vector<int>>&image2)
    {
        queue<pair<int,int>>q;
        q.push({sr,sc});
        visited[sr][sc] = true;

        image2[sr][sc] = color;
        while(!q.empty())
        {
            pair<int,int>p = q.front();
            int x = p.first;
            int y = p.second;
            q.pop();
            for(int i = 0;i<4;i++)
            {
                int newX = x+dx[i];
                int newY = y+dy[i];
                if(newX<image.size() && newX>=0 && newY<image[0].size() && newY>=0 && !visited[newX][newY] && image[newX][newY]==image[x][y])
                {
                    visited[newX][newY] = true;
                    image2[newX][newY] = color;
                    q.push({newX,newY});
                }
            }
        }
    }

    vector<vector<int>> floodFill(vector<vector<int>>& image, int sr, int sc, int color) {
        int n = image.size(),m = image[0].size();
        vector<vector<bool>>visited(n,vector<bool>(n,false));
        vector<vector<int>>image2(n,vector<int>(n,0));
        image2 = image;
        bfs(sr,sc,color,image,visited,image2);
        return image2;
    }
};