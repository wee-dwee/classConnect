// https://leetcode.com/problems/interleaving-string

class Solution {
public:
    bool solve(int i,int j,int k,string s1,string s2,string s3)
    {
       if(i>=s1.length() && j>=s2.length() && k>=s3.length())
       return true;

        if(s1[i]!=s3[k] && s2[j]!=s3[k])
        return false;

        bool ans = false;
       if(s1[i]==s3[k] && s2[j]!=s3[k])
       {
            return solve(i+1,j,k+1,s1,s2,s3);
       }
       if(s1[i]!=s3[k] && s2[j]==s3[k])
       {
            return solve(i,j+1,k+1,s1,s2,s3);
       }
       if(s1[i]==s3[k] && s2[j]==s3[k])
       {
            return solve(i+1,j,k+1,s1,s2,s3)||solve(i,j+1,k+1,s1,s2,s3);
       }
       return false;
    }
    bool isInterleave(string s1, string s2, string s3) {
        if(s3.length()!=(s1.length()+s2.length()))
        return false;
        return solve(0,0,0,s1,s2,s3);
    }
};