// https://leetcode.com/problems/interleaving-string

class Solution {
public:
    bool solve(int i,int j,int k,string s1,string s2,string s3)
    {
       if(i>=s1.length() && j>=s2.length() && k>=s3.length())
       return true;

        if(s1[i]!=s3[k] && s2[j]!=s3[k])
        return false;

        bool ans = false;
       if(s1[i]==s3[k] && s2[j]!=s3[k])
       {
            return solve(i+1,j,k+1,s1,s2,s3);
       }
       if(s1[i]!=s3[k] && s2[j]==s3[k])
       {
            return solve(i,j+1,k+1,s1,s2,s3);
       }
       if(s1[i]==s3[k] && s2[j]==s3[k])
       {
            return solve(i+1,j,k+1,s1,s2,s3)||solve(i,j+1,k+1,s1,s2,s3);
       }
       return false;
    }
    bool isInterleave(string s1, string s2, string s3) {
        if(s3.length()!=(s1.length()+s2.length()))
        return false;
        int p = s1.length(),q = s2.length(),r = s3.length();
        vector<vector<vector<int>>>dp(p+1,vector<vector<int>>(q+1,vector<int>(r+1,1)));


        for(int i = p-1;i>=0;i--)
        {
            for(int j=q-1;j>=0;j--)
            {
                for(int k=r-1;k>=0;k--)
                {
                    if(s1[i]!=s3[k] && s2[j]!=s3[k])
                    {
                        dp[i][j][k] = 0;
                    }
                    if(s1[i]==s3[k] && s2[j]!=s3[k])
                    {
                        dp[i][j][k] = dp[i+1][j][k+1];
                    }
                    if(s1[i]!=s3[k] && s2[j]==s3[k])
                    {
                        dp[i][j][k] = dp[i][j+1][k];
                    }
                    if(s1[i]==s3[k] && s2[j]==s3[k])
                    {
                        dp[i][j][k] = dp[i+1][j][k]||dp[i][j+1][k];
                    }
                }
            }
        }
        return dp[0][0][0];
    }
};