// https://leetcode.com/problems/count-alternating-subarrays

class Solution {
public:
    long long countAlternatingSubarrays(vector<int>& nums) {
        int s =  0;
        int n = nums.size();
        int count = 1;
        for(int e = 1;e<n;e++)
        {
            if(nums[e]==nums[e-1])
            {
                s=e;
            }
            count+=e-s+1;
        }
        return count;
    }
};