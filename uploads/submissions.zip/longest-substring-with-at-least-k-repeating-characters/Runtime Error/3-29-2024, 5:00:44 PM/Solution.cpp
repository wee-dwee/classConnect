// https://leetcode.com/problems/longest-substring-with-at-least-k-repeating-characters

class Solution {
public:
    int longestSubstring(string s, int k) {
        unordered_map<char,int>m;
        int l = 0,r = 0;
        int n = s.length();
        int ans = INT_MAX;
        for(auto it:s)
        m[it]++;
        while(r<n)
        {
            m[s[r]]++;
            while(m[s[r]]>=k)
            {
                
                m[s[l]]++;
                l++;
            }
            
            r++;
        }
        return ans;
    }
};