// https://leetcode.com/problems/number-of-provinces

class Solution {
public:

    void bfs(unordered_map<int,vector<int>>&m,vector<bool>&visited,int i)
    {
        queue<int>q;
        q.push(i);
        visited[i] = true;
        while(!q.empty())
        {
            int x = q.front();
            q.pop();
            for(auto it:m[x])
            {
                if(!visited[it])
                {
                    visited[it] = true;
                    q.push(it);
                }
            }
        }
    }
    int findCircleNum(vector<vector<int>>& v) {
        unordered_map<int,vector<int>>m;
        vector<bool>visited(v.size(),false);
        for(int i = 0;i<v.size();i++)
        {
            for(int j = 0;j<v.size();j++)
            {
                if(v[i][j]==1 && i!=j)
                {
                    m[i].push_back(j);
                    m[j].push_back(i);
                }
            }
        }
        int count =  0;
        for(int i = 0;i<v.size();i++)
        {
            if(!visited[i])
            {
                count++;
                bfs(m,visited,i);
            }
        }
        return count;
    }
};