// https://leetcode.com/problems/word-search

class Solution {
public:
    vector<int>dx = {-1,0,1,0};
    vector<int>dy = {0,1,0,-1};
    bool isValid(int row,int col,vector<vector<char>>&board)
    {
        int n = board.size();
        int m = board[0].size();
        if(row<n && row>=0 && col<m && col>=0)
        return true;
        return false;
    }
    bool dfs(int row,int col,vector<vector<char>>&board,string word,int index)
    {
        if(index==word.length()-1)
        return true;

        char x = board[row][col];
        board[row][col] = '.';
        if((row+1)>=0 && (row+1)<board.size() && board[row+1][col]!='.' && word[index+1]==board[row+1][col] && dfs(row+1,col,board,word,index+1))
        return true;
        if((row-1)>=0 && (row-1)<board.size() && board[row-1][col]!='.' && word[index+1]==board[row-1][col] && dfs(row-1,col,board,word,index+1))
        return true;
        if((col+1)>=0 && (col+1)<board[0].size() && board[row][col+1]!='.' && word[index+1]==board[row][col+1] && dfs(row,col+1,board,word,index+1))
        return true;
        if((col-1)>=0 && (col-1)<board[0].size() && board[row][col-1]!='.' && word[index+1]==board[row][col-1] && dfs(row,col-1,board,word,index+1))
        return true;
        board[row][col] = x;
        return false;
    }
    bool exist(vector<vector<char>>& board, string word) {
        int n = board.size();
        int m = board[0].size();
        bool ans = false;
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<m;j++)
            {
                if(board[i][j]==word[0])
                {
                    ans=ans||dfs(i,j,board,word,0);
                }
            }
        }
        return ans;
    }
};