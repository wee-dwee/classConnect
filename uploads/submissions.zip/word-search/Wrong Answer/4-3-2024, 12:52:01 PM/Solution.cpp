// https://leetcode.com/problems/word-search

class Solution {
public:
    vector<int>dx = {-1,0,1,0};
    vector<int>dy = {0,1,0,-1};
    void dfs(int row,int col,vector<vector<char>>&board,string word,int index,bool &ans)
    {
        
        if(index==word.length()-1 && word[index]==board[row][col])
        {   
            ans = true;
            return;
        }   
        if(word[index]!=board[row][col])
        {
            return;
        }
        
        for(int i = 0;i<4;i++)
        {
            int newX = row+dx[i];
            int newY = col+dy[i];
            if(newX<board.size() && newX>=0 && newY<board[0].size() && newY>=0 && board[newX][newY]==word[index+1])
            {
                dfs(newX,newY,board,word,index+1,ans);
            }
        }
    }
    bool exist(vector<vector<char>>& board, string word) {
        int n = board.size();
        int m = board[0].size();
        bool ans = false;
        for(int i = 0;i<n;i++)
        {
            for(int j = 0;j<m;j++)
            {
                if(board[i][j]==word[0])
                {
                    dfs(i,j,board,word,0,ans);
                }
            }
        }
        return ans;
    }
};