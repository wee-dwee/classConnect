// https://leetcode.com/problems/partition-array-according-to-given-pivot

class Solution {
public:
    vector<int> pivotArray(vector<int>& nums, int pivot) {
        vector<int>nums1;
        vector<int>nums2;
        int count = 0;
        for(auto it:nums)
        {
            if(it>pivot)
            {
                nums2.push_back(it);
            }
            else if(it<pivot)
                nums1.push_back(it);
            else
                count++;
        }
        for(int i = 0;i<count;i++)
        {
            nums1.push_back(pivot);
        }
        for(int i = 0;i<nums2.size();i++)
        {
            nums1.push_back(nums2[i]);
        }
        return nums1;
    }
};