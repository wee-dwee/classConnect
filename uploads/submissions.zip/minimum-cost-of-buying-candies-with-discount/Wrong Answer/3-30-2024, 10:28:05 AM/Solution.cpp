// https://leetcode.com/problems/minimum-cost-of-buying-candies-with-discount

class Solution {
public:
    int minimumCost(vector<int>& cost) {
        sort(cost.begin(),cost.end());
        int sum = 0;
        if(cost.size()<3)
        {
            int sum = 0;
            for(auto it:cost)
            {
                sum+=it;
            }
            return sum;
        }

        for(int i = 0;i<cost.size();i++)
        {
            if(i%3!=0)
            {
                sum+=cost[i];
            }
        }
        return sum;
    }
};