// https://leetcode.com/problems/minimum-cost-of-buying-candies-with-discount

class Solution {
public:
    int minimumCost(vector<int>& cost) {
        int n= cost.size();
        int i = n-1, ans = 0;
        
        if(n <= 2){
            for(auto x: cost) 
                ans += x;
            return ans;
        }
        
        sort(cost.begin(), cost.end());
        
        while(i>=1){
            ans = ans +  cost[i] + cost[i-1];
            if(i-1 == 0 || i-1 == 1) return ans;
            i = i-3;
        }
        ans += cost[0];
        
        return ans;
    }
};