// https://leetcode.com/problems/find-the-sum-of-the-power-of-all-subsequences

class Solution {
public:
    int numOfSub(vector<int>&v)
    void solve(vector<int>&nums,vector<int>&ans,vector<vector<int>>&out,int i)
    {
        if(i==nums.size())
        {
            out.push_back(ans);
            return;
        }
        ans.push_back(nums[i]);
        solve(nums,ans,out,i+1);
        ans.pop_back();
        solve(nums,ans,out,i+1);
    }
    int sumOfPower(vector<int>& nums, int k) {
        vector<vector<int>>out;
        vector<int>ans;
        solve(nums,ans,out,0);
        vector<vector<int>>possible;
        for(auto it:out)
        {
            int sum = 0;
            for(int i = 0;i<it.size();i++)
            {
                sum+=it[i];
            }
            if(sum>=k)
            {
                possible.push_back(it);
            }
        }
        int ans2 = 0;
        for(auto it:possible)
        {
            ans2+=numOfSub(it);
        }
        
        return ans2;
    }
};