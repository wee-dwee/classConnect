// https://leetcode.com/problems/find-the-sum-of-the-power-of-all-subsequences

#include <vector>
using namespace std;

class Solution {
public:
    
    void numOfSub(vector<int>& v, int k, int sum, int i, vector<vector<int>>& out, vector<int>& ans) {
        if (sum >= k) {
            out.push_back(ans);
           
            return;
        }
        if (i == v.size()) {
            return;
        }
        
        ans.push_back(v[i]);
        numOfSub(v, k, sum + v[i], i + 1, out, ans);
        ans.pop_back();
        
        numOfSub(v, k, sum-v[i], i + 1, out, ans);
    }

    
    int solve2(vector<int>& v, int k) {
        vector<vector<int>> out;
        vector<int> ans;
        numOfSub(v, k, 0, 0, out, ans);
        return out.size();
    }

    
    void solve(vector<int>& nums, vector<int>& ans, vector<vector<int>>& out, int i) {
        if (i == nums.size()) {
            out.push_back(ans);
            return;
        }
        
        ans.push_back(nums[i]);
        solve(nums, ans, out, i + 1);
        ans.pop_back();
       
        solve(nums, ans, out, i + 1);
    }

   
    int sumOfPower(vector<int>& nums, int k) {
        vector<vector<int>> out;
        vector<int> ans;
        solve(nums, ans, out, 0);
        int ans2 = 0;
        for (auto it : out) {
            int sum = 0;
            for (int i = 0; i < it.size(); i++) {
                sum += it[i];
            }
            if (sum >= k) {
                ans2++;
            }
        }
        return ans2;
    }
};


