// https://leetcode.com/problems/find-the-sum-of-the-power-of-all-subsequences

#include <vector>
using namespace std;

class Solution {
public:
    // Function to find subsets with sum equal to k
    void numOfSub(vector<int>& v, int k, int sum, int i, vector<vector<int>>& out, vector<int>& ans) {
        if (sum >= k) {
            out.push_back(ans);
            // No need to continue, as adding more elements will only increase the sum
            return;
        }
        if (i == v.size()) {
            return;
        }
        // Include the current element
        ans.push_back(v[i]);
        numOfSub(v, k, sum + v[i], i + 1, out, ans);
        ans.pop_back();
        // Exclude the current element
        numOfSub(v, k, sum, i + 1, out, ans);
    }

    // Function to count subsets with sum greater than or equal to k
    int solve2(vector<int>& v, int k) {
        vector<vector<int>> out;
        vector<int> ans;
        numOfSub(v, k, 0, 0, out, ans);
        return out.size();
    }

    // Function to generate all subsets
    void solve(vector<int>& nums, vector<int>& ans, vector<vector<int>>& out, int i) {
        if (i == nums.size()) {
            out.push_back(ans);
            return;
        }
        // Include the current element
        ans.push_back(nums[i]);
        solve(nums, ans, out, i + 1);
        ans.pop_back();
        // Exclude the current element
        solve(nums, ans, out, i + 1);
    }

    // Function to find subsets with sum greater than or equal to k among all subsets of nums
    int sumOfPower(vector<int>& nums, int k) {
        vector<vector<int>> out;
        vector<int> ans;
        solve(nums, ans, out, 0);
        int ans2 = 0;
        for (auto it : out) {
            int sum = 0;
            for (int i = 0; i < it.size(); i++) {
                sum += it[i];
            }
            if (sum >= k) {
                ans2++;
            }
        }
        return ans2;
    }
};


