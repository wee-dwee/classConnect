// https://leetcode.com/problems/sort-the-jumbled-numbers

class Solution {
public:
    static bool cmp(pair<int, int>& a, pair<int, int>& b) {
        return a.second < b.second;
    }

    int solve(int x,vector<int>&mapping)
    {
        int z = x;
        int ans = 0;
        int i = 0;
        while(z>0)
        {
            int digit = z%10;
            int toAdd = mapping[digit];
            ans+=toAdd*pow(10,i);
            z/=10;
            i++;
        }
        return ans;
    }
    vector<int> sortJumbled(vector<int>& mapping, vector<int>& nums) {
        
        
        vector<pair<int,int>>v;
        for(int i = 0;i<nums.size();i++)
        {
            int k = solve(nums[i],mapping);
            v.push_back({nums[i],k});
        }
        sort(v.begin(),v.end(),cmp);
        vector<int>ans;
        for(auto it:v)
        {
            ans.push_back(it.first);
        }
        return ans;
    }
};